<?php
session_start();

if (isset($_SESSION['username'])) {
    header('Location: user_page.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Strona logowania</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="index is-preload">
    <div id="page-wrapper">
        <article id="main">
            <header class="special container">
                <span class="icon fa-address-book"></span>
                <h2>Logowanie</h2>
            </header>
            
            <section class="wrapper style4 special container medium">
                <div class="content">
                    <form action="login_process.php" method="post">
                        <div class="row gtr-50">
                            <div class="col-6 col-12-mobile">
                                <input type="text" name="user_name" placeholder="Login" required>
                            </div>    
                            <div class="col-6 col-12-mobile">   
                                <input type="password" name="password" placeholder="Hasło" required>
                            </div>    
                            <div class="col-12">
                                <ul class="buttons">
                                    <li><input type="submit" class="special" value="Zaloguj się" /></li>
                                </ul>
                            </div>
                        </div>    
                    </form>
                </div>        
                <br><a href="register.php">Nie masz jeszcze konta? Zarejestruj się tutaj</a><br><br>
                <a href="index.php#main">Powrót do strony głównej</a>
            </section>
   
            <footer id="footer">
                <ul class="icons">
                    <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
                </ul>
                <ul class="copyright">
                    <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                </ul>
            </footer>
        </article>    
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollgress.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>