<?php
session_start(); // Start sesji

$message = "";
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Usunięcie komunikatu z sesji po wyświetleniu
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <title>Strona rejestracji</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="index is-preload">
    <div id="page-wrapper">
        <article id="main">
            <header class="special container">
                <span class="icon fa-address-card"></span>
                <h2>Rejestrowanie</h2>
                <?php if ($message != ""): ?>
                    <div class="alert" style="color: red;"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
            </header>
            
            <section class="wrapper style4 special container medium">
                <div class="content">
                    <form action="register_process.php" method="post">
                        <div class="row gtr-50">
                            <div class="col-6">
                                <label for="login">Login</label>
                                <input type="text" id="login" name="login" placeholder="Login" required><br>

                                <label for="first_name">Imię</label>
                                <input type="text" id="first_name" name="first_name" placeholder="Imię" required><br>

                                <label for="birthday">Data urodzenia</label>
                                <input type="date" id="birthday" name="birthday" required value="1970-01-01"><br>
                            </div>   
                            <div class="col-6">
                                <label for="password">Hasło</label>
                                <input type="password" id="password" name="password" placeholder="Hasło" required><br>            

                                <label for="surname">Nazwisko</label>
                                <input type="text" id="surname" name="surname" placeholder="Nazwisko" required><br>

                                <label for="email">E-mail</label>
                                <input type="email" id="email" name="email" placeholder="Adres e-mail" required><br>
                            </div>
                            <div class="col-12">
                                <ul class="buttons">
                                    <li><input type="submit" class="special" value="Zarejestruj się" /></li>
                                </ul>
                            </div>
                        </div>
                    </form>
                </div>
                
                <br><a href="login.php">Masz już konto? Zaloguj się tutaj</a><br><br>
                <a href="index.php#main">Powrót do strony głównej</a>
            </section>
   
            <footer id="footer">
                <ul class="icons">
                    <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
                </ul>
                <ul class="copyright">
                    <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                </ul>
            </footer>
        </article>    
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollgress.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>