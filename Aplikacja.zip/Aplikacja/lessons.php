<?php
include_once('db_connect.php');
session_start(); // Start sesji

// Pobranie wszystkich lekcji z bazy danych
$query = "SELECT id_lekcji, nazwa_lekcji, poziom_lekcji, data_utworzenia_lekcji FROM lekcje";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Lekcje</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="index is-preload">
<div id="page-wrapper">
    <!-- Header -->
    <header id="header" class="alt">
        <h1 id="logo">Aplikacja do nauki języka hiszpańskiego</h1>
        <nav id="nav">
            <ul>
                <li class="current"><a href="index.php">Strona główna</a></li>
                <li><a href="lessons.php" class="button primary">Lekcje</a></li>
                <?php
                if(isset($_SESSION['user_id'])) {
                    if ($_SESSION['role_id'] == '1') {
                        echo '<li><a href="admin_page.php" class="button primary">Moje konto</a></li>';
                    } else if ($_SESSION['role_id'] == '2') {
                        echo '<li><a href="admin_page.php" class="button primary">Moje konto</a></li>';
                    } else if ($_SESSION['role_id'] == '3') {
                        echo '<li><a href="user_page.php" class="button primary">Moje konto</a></li>';
                    }
                } else {
                    echo '<li><a href="login.php" class="button primary">Zaloguj się</a></li>';
                }
                ?>
            </ul>
        </nav>
    </header>

    <!-- Main Content -->
    <article id="main">
        <header class="special container">
            <span class="icon solid fa-book"></span>
            <h2>Dostępne Lekcje</h2>
        </header>

        <!-- Lekcje -->
        <section class="wrapper style2 container special-alt">
            <div class="row gtr-50">
                <div class="col-12">
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th style="text-align: left;">Nazwa lekcji</th>
                                    <th style="text-align: left;">Poziom lekcji</th>
                                    <th style="text-align: left;">Treść lekcji</th>
                                    <th style="text-align: left;">Akcja</th> <!-- Dodaj nową kolumnę dla przycisku -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($result) > 0) { ?>
                                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                                        <tr>
                                            <td><?php echo $row['nazwa_lekcji']; ?></td>
                                            <td><?php echo $row['poziom_lekcji']; ?></td>
                                            <td>Treść dostępna po dodaniu jej do swojego panelu</td>
                                            <td>
                                            <!-- Dodaj przycisk "Dodaj do swoich lekcji" -->
                                            <form action="add_to_user_lessons.php" method="post">
                                                <input type="hidden" name="lesson_id" value="<?php echo $row['id_lekcji']; ?>">
                                                <input type="submit" value="Dodaj do swoich lekcji">
                                            </form>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="4">Brak dostępnych lekcji.</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </article>

    <!-- Footer -->
    <footer id="footer">
        <ul class="icons">
            <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
        </ul>
        <ul class="copyright">
            <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
        </ul>
    </footer>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>