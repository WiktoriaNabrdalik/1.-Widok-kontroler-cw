<?php
    session_start(); // Start sesji
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Poziom A2</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="assets/css/main.css" />
        <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
    </head>
    <body class="right-sidebar is-preload">
        <div id="page-wrapper">
            <!-- Header -->
            <header id="header">
                <h1 id="logo">Aplikacja do nauki języka hiszpańskieg</h1>
                <nav id="nav">
                    <ul>
                        <li class="current"><a href="index.php">Strona główna</a></li>
                        <?php
                            if(isset($_SESSION['user_id'])) {
                                echo '<li><a href="user_page.php" class="button primary">Moje konto</a></li>';
                            } else {
                                echo '<li><a href="login.php" class="button primary">Zaloguj się</a></li>';
                            }
                        ?>
                    </ul>
                </nav>
            </header>

            <!-- Main -->
            <article id="main">
                <header class="special container">
                    <span class="icon solid fa-laptop"></span>
                    <h2>Poziom <strong>A2</strong></h2>
                    <!-- <p>Where things on the right ... accompany that on the left.</p> -->
                </header>

                <!-- One -->
                <section class="wrapper style4 container">
                    <div class="row gtr-150">
                        <div class="col-8 col-12-narrower">
                            <!-- Content -->
                            <div class="content">
                                <section>
                                    <a class="image featured"><img src="images/body.jpg" alt="" /></a>
                                    <header><h3>Poziom podstawowy: A2</h3></header>
                                    <p>Poziom A2 w nauce języka hiszpańskiego jest przeznaczony dla osób, które opanowały podstawy języka i chcą rozwijać swoje umiejętności, aby lepiej radzić sobie w codziennych sytuacjach oraz w prostych rozmowach na znane tematy.</p>
                                    <header><h3>Cele nauki:</h3></header>
                                    <p>• Rozumienie zdań i często używanych wyrażeń związanych z obszarami najbardziej bezpośrednio dotyczącymi (np. bardzo podstawowe informacje o sobie i rodzinie, zakupy, lokalizacja geograficzna, zatrudnienie).</p>
                                    <p>• Komunikowanie się w prostych, rutynowych sytuacjach wymagających prostego i bezpośredniego wymiany informacji na znane tematy.</p>
                                    <p>• Opisywanie w prosty sposób aspektów swojego pochodzenia i środowiska, oraz wyrażanie swoich bezpośrednich potrzeb.</p>
                                </section>
                            </div>
                        </div>
                            <div class="col-4 col-12-narrower">
                            <!-- Sidebar -->
                            <div class="sidebar">
                                <section>
                                    <header><h3>Zakres materiału:</h3></header>
                                    <p><h3>1. Rozszerzona gramatyka:</h3></p>
                                    <p>• Stopniowanie przymiotników. <br>
                                    • Czasowniki nieregularne w czasie teraźniejszym.<br>
                                    • Czas przeszły prosty (pretérito perfecto).<br>
                                    • Czas przyszły (futuro simple).<br>
                                    • Zaawansowane użycie czasowników ser i estar<br>
                                    • Zaimki osobowe, dzierżawcze i zwrotne.</p>
                                    <p><h3>2. Rozszerzone słownictwo:</h3></p>
                                    <p>• Części ciała i zdrowie.<br>
                                    • Zakupy i usługi (w sklepie, na poczcie, w banku).<br>
                                    • Podróże i transport.<br>
                                    • Jedzenie i napoje, kuchnia i gotowanie.<br>
                                    • Praca i zawody.<br>
                                    • Dom i wyposażenie.</p>
                                    <p><h3>3. Komunikacja:</h3></p>
                                    <p>• Opisywanie codziennych czynności i rutyn.<br>
                                    • Mówienie o przeszłych wydarzeniach.<br>
                                    • Wyrażanie przyszłych planów i zamiarów.<br>
                                    • Opisywanie swoich upodobań, zainteresowań i opinii.<br>
                                    • Udzielanie rad i sugestii.</p>
                                </section>
                                </div>
                        </div>
                    </div>
            </section>

             <!-- Two -->
             <section class="wrapper style1 container special">
                    <div class="row">
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>Poziom początkujący</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie A1?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="A1.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>Poziom średnio zaawansowany</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie B1?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="B1.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>POZIOM PONAD ŚREDNIO ZAAWANSOWANY</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie B2?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="B2.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                    </div>
                </section>
            </article>

            <!-- Footer -->
            <footer id="footer">
                <ul class="icons">
                    <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
                </ul>
                <ul class="copyright">
                    <li>&copy; Wiktoria Nabrdalik</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                </ul>
            </footer>

        </div>

        <!-- Scripts -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/jquery.dropotron.min.js"></script>
        <script src="assets/js/jquery.scrolly.min.js"></script>
        <script src="assets/js/jquery.scrollgress.min.js"></script>
        <script src="assets/js/jquery.scrollex.min.js"></script>
        <script src="assets/js/browser.min.js"></script>
        <script src="assets/js/breakpoints.min.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/main.js"></script>

    </body>
</html>