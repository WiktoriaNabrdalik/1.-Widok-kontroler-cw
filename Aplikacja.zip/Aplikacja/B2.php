<p?php
    session_start(); // Start sesji
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Poziom B2</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="assets/css/main.css" />
        <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
    </head>
    <body class="right-sidebar is-preload">
        <div id="page-wrapper">
            <!-- Header -->
            <header id="header">
                <h1 id="logo">Aplikacja do nauki języka hiszpańskieg</h1>
                <nav id="nav">
                    <ul>
                        <li class="current"><a href="index.php">Strona główna</a></li>
                        <?php
                            if(isset($_SESSION['user_id'])) {
                                echo '<li><a href="user_page.php" class="button primary">Moje konto</a></li>';
                            } else {
                                echo '<li><a href="login.php" class="button primary">Zaloguj się</a></li>';
                            }
                        ?>
                    </ul>
                </nav>
            </header>

            <!-- Main -->
            <article id="main">
                <header class="special container">
                    <span class="icon solid fa-laptop"></span>
                    <h2>Poziom <strong>B1</strong></h2>
                    <!-- <p>Where things on the right ... accompany that on the left.</p> -->
                </header>

                <!-- One -->
                <section class="wrapper style4 container">
                    <div class="row gtr-150">
                        <div class="col-8 col-12-narrower">
                            <!-- Content -->
                            <div class="content">
                                <section>
                                    <a class="image featured"><img src="images/czas.jpg" alt="" /></a>
                                    <header><h3>Poziom ponad średnio zaawansowany: B2</h3></header>
                                    <p>Poziom B2 w nauce języka hiszpańskiego jest przeznaczony dla osób, które posiadają zaawansowane umiejętności językowe i chcą doskonalić swoje zdolności komunikacyjne w bardziej złożonych sytuacjach.</p>
                                    <p> Na tym poziomie uczniowie rozwijają swoją biegłość językową, zdolność do wyrażania opinii i uczestniczenia w dyskusjach na różnorodne tematy.</p>
                                    <header><h3>Cele nauki:</h3></header>
                                    <p>• Komunikowanie się w języku hiszpańskim w sposób płynny i swobodny w różnorodnych sytuacjach, zarówno w sferze osobistej, jak i zawodowej.</p>
                                    <p>• Wyrażanie złożonych poglądów i argumentacji na różne tematy, z uwzględnieniem różnorodnych punktów widzenia.</p>
                                    <p>• Rozumienie zaawansowanych tekstów i dyskusji dotyczących spraw społecznych, politycznych i kulturalnych.</p>
                                    <p>• Pisanie strukturalnie poprawnych i złożonych tekstów, w tym esejów, raportów i analiz.</p>
                                </section>
                            </div>
                        </div>
                            <div class="col-4 col-12-narrower">
                            <!-- Sidebar -->
                            <div class="sidebar">
                                <section>
                                    <header><h3>Zakres materiału:</h3></header>
                                    <p><h3>1. Zaawansowana gramatyka:</h3></p>
                                    <p>• Użycie trybu przypuszczającego (modo subjuntivo) w złożonych zdaniach.<br>
                                    • Zdania podrzędne przysłówkowe i przydawkowe.<br>
                                    • Czasy przeszłe (pretérito perfecto, pretérito indefinido, pretérito imperfecto) i ich zastosowania.<br>
                                    • Konstrukcje porównawcze i przeciwstawne.<br>
                                    • Użycie przysłówków i przysłowków czasu.</p>
                                    <p><h3>2. Zaawansowane słownictwo:</h3></p>
                                    <p>• Polityka i społeczeństwo.<br>
                                    • Ekonomia i biznes.<br>
                                    • Nauka i technologia.<br>
                                    • Sztuka i kultura.<br>
                                    • Historia i współczesność.<br>
                                    • Religia i filozofia.</p>
                                    <p><h3>3. Komunikacja:</h3></p>
                                    <p>• Prowadzenie dyskusji na różnorodne tematy, wyrażanie poglądów i argumentacji<br>
                                    • Omawianie złożonych kwestii społecznych, politycznych i ekonomicznych.<br>
                                    • Wyrażanie przekonań i planów na przyszłość.<br>
                                    • Prezentowanie poglądów na tematy kontrowersyjne.<br>
                                    • Radzenie sobie w sytuacjach konfliktowych i negocjacyjnych.</p>
                                </section>
                                </div>
                        </div>
                    </div>
            </section>

             <!-- Two -->
             <section class="wrapper style1 container special">
                    <div class="row">
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>Poziom początkujący</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie A1?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="A1.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>Poziom podstawowy</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie A2?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="A2.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>POZIOM ŚREDNIO ZAAWANSOWANY</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie B1?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="B1.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                    </div>
                </section>
            </article>

            <!-- Footer -->
            <footer id="footer">
                <ul class="icons">
                    <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
                </ul>
                <ul class="copyright">
                    <li>&copy; Wiktoria Nabrdalik</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                </ul>
            </footer>

        </div>

        <!-- Scripts -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/jquery.dropotron.min.js"></script>
        <script src="assets/js/jquery.scrolly.min.js"></script>
        <script src="assets/js/jquery.scrollgress.min.js"></script>
        <script src="assets/js/jquery.scrollex.min.js"></script>
        <script src="assets/js/browser.min.js"></script>
        <script src="assets/js/breakpoints.min.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/main.js"></script>

    </body>
</html>