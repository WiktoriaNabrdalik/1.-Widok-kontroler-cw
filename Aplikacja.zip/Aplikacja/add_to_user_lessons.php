<?php
session_start();

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Sprawdzenie, czy dane formularza zostały przesłane
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['lesson_id'])) {
    include_once('db_connect.php');

    $user_id = $_SESSION['user_id'];
    $lesson_id = $_POST['lesson_id'];

    // Sprawdzenie, czy lekcja już istnieje w panelu użytkownika
    $query = "SELECT * FROM uzytkownik_lekcje WHERE id_uzytkownik = '$user_id' AND id_lekcji = '$lesson_id'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 0) {
        // Dodanie lekcji do panelu użytkownika
        $insert_query = "INSERT INTO uzytkownik_lekcje (id_uzytkownik, id_lekcji) VALUES ('$user_id', '$lesson_id')";
        $insert_result = mysqli_query($conn, $insert_query);

        if ($insert_result) {
            // Lekcja została dodana pomyślnie
            $success_message = "Lekcja została dodana do Twojego panelu użytkownika.";
        } else {
            // Błąd podczas dodawania lekcji
            $error_message = "Błąd podczas dodawania lekcji.";
        }
    } else {
        // Lekcja już istnieje w panelu użytkownika
        $error_message = "Ta lekcja już znajduje się w Twoim panelu użytkownika.";
    }
} else {
    // Dane formularza nie zostały przesłane
    $error_message = "Nieprawidłowe żądanie.";
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Dodaj do swoich lekcji</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="no-sidebar is-preload">
<div id="page-wrapper">

    <!-- Header -->
    <header id="header" class="alt">
        <h1 id="logo"><a href="index.php"><span></span></a></h1>
    </header>
<!-- Main -->
<article id="main">
    <header class="special container">
        <span class="icon solid fa-sign-out-alt"></span>
        <h2>Dodaj do swoich lekcji</h2>
        <?php if(isset($success_message)) { ?>
            <p style="text-align:center;"><?php echo $success_message; ?></p>
        <?php } elseif(isset($error_message)) { ?>
            <p style="text-align:center;"><?php echo $error_message; ?></p>
        <?php } ?>
        <a href="user_page.php">Powrót do strony użytkownika</a>
    </header>
</article>

    <!-- Footer -->
    <footer id="footer">
        <ul class="icons">
            <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
        </ul>
        <ul class="copyright">
            <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
        </ul>
    </footer>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/jquery.scrollgress.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>