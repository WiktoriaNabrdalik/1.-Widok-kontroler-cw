<?php

include_once('db_connect.php'); // Połączenie z bazą danych

// Sprawdzenie czy formularz został wysłany
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pobranie danych z formularza
    $user_name = $_POST["user_name"];
    echo "Login z formularza: ".$user_name;
    $password = $_POST["password"];
    echo "<br>Hasło z formularza: ".$password;

    // Zapytanie do bazy danych w celu pobrania danych użytkownika
    $sql = "SELECT * FROM uzytkownik_rola LEFT JOIN uzytkownicy ON id_uzyt_rola = id_uzyt WHERE login_uzyt_rola=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $user_name);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $db_password = $row['haslo_uzyt_rola'];
        
        if ($password == $db_password) {
            session_start(); // Start sesji
            
            // Utworzenie parametrów sesji
            $_SESSION['user_id'] = $row['id_uzyt_uzyt_rola'];
            $_SESSION['username'] = $row['login_uzyt_rola']; // Zmiana na 'username'
            $_SESSION['user_email'] = $row['email_uzyt'];
            $_SESSION['role_id'] = $row['id_role_uzyt_rola'];

            // Debugowanie
            echo "Role ID: " . $_SESSION['role_id'];
            echo "User Name: " . $_SESSION['username'];
            
            // Przekierowanie na odpowiednią stronę w zależności od roli użytkownika
            if ($_SESSION['role_id'] == '1') {
                header("Location: admin_page.php");
                exit();
            } else if ($_SESSION['role_id'] == '2') {
                header("Location: moder_page.php"); // Przekierowanie dla moderatora
                exit();
            } else if ($_SESSION['role_id'] == '3') {
                header("Location: user_page.php");
                exit();
            } else {
                header("Location: index.php");
                exit();
            }          
        } else {
            $_SESSION['error_message'] = "Błędne hasło!";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error_message'] = "Użytkownik nie istnieje!";
        header("Location: login.php");
        exit();
    }
}