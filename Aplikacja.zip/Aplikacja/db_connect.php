<?php
$db_host = 'localhost';
$db_user = 'user'; // Nazwa użytkownika bazy danych
$db_pass = 'user'; // Hasło użytkownika bazy danych
$db_name = 'aplikacja_hiszpanski'; // Nazwa bazy danych

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
}
