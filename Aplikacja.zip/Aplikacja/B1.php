<?php
    session_start(); // Start sesji
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Poziom B1</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="assets/css/main.css" />
        <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
    </head>
    <body class="right-sidebar is-preload">
        <div id="page-wrapper">
            <!-- Header -->
            <header id="header">
                <h1 id="logo">Aplikacja do nauki języka hiszpańskieg</h1>
                <nav id="nav">
                    <ul>
                        <li class="current"><a href="index.php">Strona główna</a></li>
                        <?php
                            if(isset($_SESSION['user_id'])) {
                                echo '<li><a href="user_page.php" class="button primary">Moje konto</a></li>';
                            } else {
                                echo '<li><a href="login.php" class="button primary">Zaloguj się</a></li>';
                            }
                        ?>
                    </ul>
                </nav>
            </header>

            <!-- Main -->
            <article id="main">
                <header class="special container">
                    <span class="icon solid fa-laptop"></span>
                    <h2>Poziom <strong>B1</strong></h2>
                    <!-- <p>Where things on the right ... accompany that on the left.</p> -->
                </header>

                <!-- One -->
                <section class="wrapper style4 container">
                    <div class="row gtr-150">
                        <div class="col-8 col-12-narrower">
                            <!-- Content -->
                            <div class="content">
                                <section>
                                    <a class="image featured"><img src="images/narzedzia.jpg" alt="" /></a>
                                    <header><h3>Poziom średnio zaawansowany: B1</h3></header>
                                    <p>Poziom B1 w nauce języka hiszpańskiego jest przeznaczony dla osób, które opanowały podstawy języka i chcą poszerzać swoje umiejętności w zakresie bardziej złożonych sytuacji komunikacyjnych. </p>
                                    <p>Na tym poziomie uczniowie uczą się wyrażać opinie, omawiać doświadczenia i radzić sobie w sytuacjach wymagających bardziej szczegółowej komunikacji.</p>
                                    <header><h3>Cele nauki:</h3></header>
                                    <p>• Rozumienie głównych punktów rozmów dotyczących znanych tematów, takich jak praca, szkoła, czas wolny itp.</p>
                                    <p>• Radzenie sobie w większości sytuacji, które mogą się pojawić podczas podróży w obszarze, gdzie mówi się po hiszpańsku.</p>
                                    <p>• Tworzenie prostych, spójnych tekstów na tematy, które są znane lub które dotyczą osobistych zainteresowań.</p>
                                    <p>• Opisywanie doświadczeń, wydarzeń, marzeń, nadziei i ambicji oraz krótko uzasadnianie swoich opinii i planów.</p>
                                </section>
                            </div>
                        </div>
                            <div class="col-4 col-12-narrower">
                            <!-- Sidebar -->
                            <div class="sidebar">
                                <section>
                                    <header><h3>Zakres materiału:</h3></header>
                                    <p><h3>1. Zaawansowana gramatyka:</h3></p>
                                    <p>• Czas przeszły złożony (pretérito perfecto compuesto). <br>
                                    • Czas przeszły prosty i niedokonany (pretérito indefinido i imperfecto).<br>
                                    • Mowa zależna.<br>
                                    • Tryb łączący (subjuntivo) w prostych zdaniach.<br>
                                    • Zaawansowane użycie zaimków (osobowych, dzierżawczych, zwrotnych).<br>
                                    • Strona bierna.</p>
                                    <p><h3>2. Zaawansowane słownictwo:</h3></p>
                                    <p>• Zdrowie i medycyna.<br>
                                    • Edukacja i nauka.<br>
                                    • Kultura i sztuka.<br>
                                    • Technologie i media.<br>
                                    • Środowisko i ekologia.<br>
                                    • Relacje międzyludzkie i emocje.</p>
                                    <p><h3>3. Komunikacja:</h3></p>
                                    <p>• Opisywanie doświadczeń i wydarzeń z przeszłości.<br>
                                    • Wyrażanie opinii, uczuć i sugestii.<br>
                                    • Prowadzenie dyskusji na znane tematy.<br>
                                    • Radzenie sobie w sytuacjach awaryjnych i nieoczekiwanych.<br>
                                    • Prowadzenie bardziej zaawansowanych rozmów telefonicznych i korespondencji.</p>
                                </section>
                                </div>
                        </div>
                    </div>
            </section>

             <!-- Two -->
             <section class="wrapper style1 container special">
                    <div class="row">
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>Poziom początkujący</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie A1?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="A1.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>Poziom podstawowy</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie A2?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="A2.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                        <div class="col-4 col-12-narrower">
                            <section>
                                <header>
                                    <h3>POZIOM PONAD ŚREDNIO ZAAWANSOWANY</h3>
                                </header>
                                <p>Chcesz zobaczyć czego nauczysz się na poziomie B2?</p>
                                <footer>
                                    <ul class="buttons">
                                        <li><a href="B2.php" class="button small">Przechodzę do innego poziomu</a></li>
                                    </ul>
                                </footer>
                            </section>
                        </div>
                    </div>
                </section>
            </article>

            <!-- Footer -->
            <footer id="footer">
                <ul class="icons">
                    <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
                </ul>
                <ul class="copyright">
                    <li>&copy; Wiktoria Nabrdalik</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                </ul>
            </footer>

        </div>

        <!-- Scripts -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/jquery.dropotron.min.js"></script>
        <script src="assets/js/jquery.scrolly.min.js"></script>
        <script src="assets/js/jquery.scrollgress.min.js"></script>
        <script src="assets/js/jquery.scrollex.min.js"></script>
        <script src="assets/js/browser.min.js"></script>
        <script src="assets/js/breakpoints.min.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/main.js"></script>

    </body>
</html>