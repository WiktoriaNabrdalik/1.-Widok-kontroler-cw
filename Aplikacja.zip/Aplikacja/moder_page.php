<?php
include_once('db_connect.php');
session_start(); // Start sesji

// Sprawdzenie czy użytkownik jest zalogowany i czy jest moderatorem
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != '2') {
    header("Location: login.php"); // Jeśli nie, przekierowanie na stronę logowania
    exit; 
}

$user_id = $_SESSION['user_id'];
$logged_in_username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Pobranie wszystkich lekcji z bazy danych
$sql = "SELECT id_lekcji, nazwa_lekcji, poziom_lekcji FROM lekcje";
$result = mysqli_query($conn, $sql);
if ($result && mysqli_num_rows($result) > 0) {
    $poziomy = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $poziom = $row['poziom_lekcji'];
        if (!isset($poziomy[$poziom])) {
            $poziomy[$poziom] = array();
        }
        array_push($poziomy[$poziom], $row);
    }
}


// Obsługa dodawania lekcji
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_lesson'])) {
    $nazwa_lekcji = $_POST['nazwa_lekcji'];
    $tresc_lekcji = $_POST['tresc_lekcji'];
    $poziom_lekcji = $_POST['poziom_lekcji'];
    $data_utworzenia_lekcji = date('Y-m-d'); // Aktualna data

    $sql = "INSERT INTO lekcje (nazwa_lekcji, tresc_lekcji, poziom_lekcji, data_utworzenia_lekcji) 
            VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $nazwa_lekcji, $tresc_lekcji, $poziom_lekcji, $data_utworzenia_lekcji);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_affected_rows($stmt) > 0) {
        echo "Lekcja została dodana pomyślnie.";
    } else {
        echo "Błąd podczas dodawania lekcji.";
    }
}

// Obsługa modyfikacji lekcji
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_lesson'])) {
    $id_lekcji = $_POST['id_lekcji'];
    $nazwa_lekcji = $_POST['nazwa_lekcji'];
    $tresc_lekcji = $_POST['tresc_lekcji'];
    $poziom_lekcji = $_POST['poziom_lekcji'];

    $sql = "UPDATE lekcje SET nazwa_lekcji=?, tresc_lekcji=?, poziom_lekcji=? WHERE id_lekcji=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssi", $nazwa_lekcji, $tresc_lekcji, $poziom_lekcji, $id_lekcji);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_affected_rows($stmt) > 0) {
        echo "Lekcja została zmodyfikowana pomyślnie.";
    } else {
        echo "Błąd podczas modyfikacji lekcji.";
    }
}

// Obsługa usuwania lekcji
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_lesson'])) {
    $id_lekcji = $_POST['lesson_id'];

    // Rozpocznij transakcję
    mysqli_begin_transaction($conn);

    try {
        // Usuń powiązane rekordy w tabeli `uzytkownik_lekcje`
        $sql_delete_user_lessons = "DELETE FROM uzytkownik_lekcje WHERE id_lekcji = ?";
        $stmt_delete_user_lessons = mysqli_prepare($conn, $sql_delete_user_lessons);
        mysqli_stmt_bind_param($stmt_delete_user_lessons, "i", $id_lekcji);
        mysqli_stmt_execute($stmt_delete_user_lessons);

        // Usuń lekcję
        $sql_delete_lesson = "DELETE FROM lekcje WHERE id_lekcji = ?";
        $stmt_delete_lesson = mysqli_prepare($conn, $sql_delete_lesson);
        mysqli_stmt_bind_param($stmt_delete_lesson, "i", $id_lekcji);
        mysqli_stmt_execute($stmt_delete_lesson);

        // Zatwierdź transakcję
        mysqli_commit($conn);

        if (mysqli_stmt_affected_rows($stmt_delete_lesson) > 0) {
            echo "Lekcja została usunięta pomyślnie.";
        } else {
            echo "Błąd podczas usuwania lekcji.";
        }
    } catch (Exception $e) {
        // Wycofaj transakcję w przypadku błędu
        mysqli_rollback($conn);
        echo "Wystąpił błąd: " . $e->getMessage();
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Panel Moderatora</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/noscript.css" /> 
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="index is-preload">
    <div id="page-wrapper">
        <!-- Header -->
        <header id="header" class="alt">
        <h1 id="logo">Panel moderatora</h1>
            <nav id="nav">
                <ul>
                    <li><a href="index.php" class="button">Strona główna</a></li>
                    <li><a href="logout.php" class="button">Wyloguj się</a></li>
                </ul>
            </nav>
        </header>

         <!-- Banner -->
         <section id="banner">
            <div class="inner">
                <header>
                    <h2>Witaj moderatorze!</h2>
                </header>
            </div>
        </section>

      <!-- Lista wszystkich lekcji -->
<article id="main">
    <section class="wrapper style2 container special-alt">
        <div class="row gtr-50">
            <div class="col-12">
                <header>
                    <h2>Lista wszystkich lekcji</h2>
                </header>
                <table>
                    <thead>
                        <tr>
                            <th style="text-align: left;">Nazwa lekcji</th>
                            <th style="text-align: left;">Poziom</th>
                            <th style="text-align: left;">Akcja</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($poziomy as $poziom => $lekcje) {
                            foreach ($lekcje as $lekcja) {
                                echo "<tr>";
                                echo "<td>{$lekcja['nazwa_lekcji']}</td>";
                                echo "<td>{$lekcja['poziom_lekcji']}</td>";
                                echo "<td><form method='post'><input type='hidden' name='lesson_id' value='" . $lekcja['id_lekcji'] . "'><button type='submit' name='delete_lesson'>Usuń lekcję</button></form></td>";
                                echo "</tr>";
                            }
                        }
                        ?>
                        </tbody>
                </table>
            </div>
        </div>
    </section>
</article>
 <!-- Formularz dodawania lekcji -->
 <article id="main">
        <section class="wrapper style2 container special-alt">
            <div class="row gtr-50">
                <div class="col-12">
                    <header>
                        <h2>Dodaj lekcję</h2>
                    </header>
                    <form method="post" action="">
                        <div class="row gtr-uniform">
                            <div class="col-12">
                                <input type="text" name="nazwa_lekcji" placeholder="Nazwa lekcji" required><br>
                            </div>
                            <div class="col-12">
                                <textarea name="tresc_lekcji" placeholder="Treść lekcji" rows="6" required></textarea><br>
                            </div>
                            <div class="col-12">
                                <select name="poziom_lekcji" required>
                                    <option value="A1">A1</option>
                                    <option value="A2">A2</option>
                                    <option value="B1">B1</option>
                                    <option value="B2">B2</option>
                                </select><br>
                            </div>
                            <div class="col-12">
                                <input type="submit" value="Dodaj lekcję" name="add_lesson" class="primary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </article>

    <!-- Formularz modyfikacji lekcji -->
    <article id="main">
        <section class="wrapper style2 container special-alt">
            <div class="row gtr-50">
                <div class="col-12">
                    <header>
                        <h2>Modyfikuj lekcję</h2>
                    </header>
                    <form method="post" action="">
                        <div class="row gtr-uniform">
                            <div class="col-12">
                                <select name="id_lekcji" required>
                                    <option value="">Wybierz lekcję</option>
                                    <?php
                                    // Pobranie wszystkich lekcji z bazy danych
                                    $sql = "SELECT id_lekcji, nazwa_lekcji FROM lekcje";
                                    $result = mysqli_query($conn, $sql);
                                    if ($result && mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<option value='{$row['id_lekcji']}'>{$row['nazwa_lekcji']}</option>";
                                        }
                                    }
                                    ?>
                                </select><br>
                            </div>
                            <div class="col-12">
                                <input type="text" name="nazwa_lekcji" placeholder="Nowa nazwa lekcji" required><br>
                            </div>
                            <div class="col-12">
                                <textarea name="tresc_lekcji" placeholder="Nowa treść lekcji" rows="6" required></textarea><br>
                            </div>
                            <div class="col-12">
                                <select name="poziom_lekcji" required>
                                    <option value="A1">A1</option>
                                    <option value="A2">A2</option>
                                    <option value="B1">B1</option>
                                    <option value="B2">B2</option>
                                </select><br>
                            </div>
                            <div class="col-12">
                                <input type="submit" value="Modyfikuj lekcję" name="edit_lesson" class="primary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </article>
</div>
</body>
</html>
<!-- Footer -->
<footer id="footer">
    <ul class="icons">
        <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
    </ul>
    <ul class="copyright">
        <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
    </ul>
</footer>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>

<?php
$conn->close();
?>