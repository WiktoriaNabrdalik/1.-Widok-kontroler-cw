<?php
session_start();
unset($_SESSION['user_id']);
session_unset();
session_destroy(); // Zniszczenie sesji
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Wylogowano</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="no-sidebar is-preload">
<div id="page-wrapper">

    <!-- Header -->
    <header id="header" class="alt">
        <h1 id="logo"><a href="index.php"><span></span></a></h1>
    </header>

    <!-- Main -->
    <article id="main">
        <header class="special container">
            <span class="icon solid fa-sign-out-alt"></span>
            <h2>Wylogowano pomyślnie</h2>
            <a href="index.php">Powrót do strony głównej</a>
        </header>
    </article>

    <!-- Footer -->
    <footer id="footer">
        <ul class="icons">
            <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
        </ul>
        <ul class="copyright">
            <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
        </ul>
    </footer>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/jquery.scrollgress.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>
