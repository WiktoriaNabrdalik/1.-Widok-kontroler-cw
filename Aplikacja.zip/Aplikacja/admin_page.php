<?php
include_once('db_connect.php');
session_start(); // Start sesji

// Sprawdzenie czy użytkownik jest zalogowany i czy jest administratorem
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != '1') {
    header("Location: login.php"); // Jeśli nie, przekierowanie na stronę logowania
    exit; 
}

$user_id = $_SESSION['user_id'];
$logged_in_username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Wyszukiwanie użytkowników i pobieranie wszystkich użytkowników
$users = [];
$query = "SELECT * FROM uzytkownik_rola";

if (isset($_POST['search_users']) || isset($_POST['show_all_users'])) {
    if (isset($_POST['search_users'])) {
        $search_keyword = $_POST['search_keyword'];
        $role_filter = $_POST['role_filter'];
        $query .= " WHERE login_uzyt_rola LIKE '%$search_keyword%'";
        if (!empty($role_filter)) {
            $query .= " AND id_role_uzyt_rola = $role_filter";
        }
    }
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Pobierz lekcje użytkownika
            $user_lessons_query = "SELECT nazwa_lekcji FROM lekcje INNER JOIN uzytkownik_lekcje ON lekcje.id_lekcji = uzytkownik_lekcje.id_lekcji WHERE uzytkownik_lekcje.id_uzytkownik = '{$row['id_uzyt_rola']}'";
            $user_lessons_result = mysqli_query($conn, $user_lessons_query);
            $lessons = [];
            if ($user_lessons_result && mysqli_num_rows($user_lessons_result) > 0) {
                while ($lesson_row = mysqli_fetch_assoc($user_lessons_result)) {
                    $lessons[] = $lesson_row['nazwa_lekcji'];
                }
            }
            $row['lekcje'] = $lessons;
            $users[] = $row;
        }
    }
}

$conn->close();
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Panel Administratora</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="index is-preload">
    <div id="page-wrapper">
        <!-- Header -->
        <header id="header" class="alt">
        <h1 id="logo">Panel administratora</h1>
            <nav id="nav">
                <ul>
                    <li><a href="index.php" class="button">Strona główna</a></li>
                    <li><a href="logout.php" class="button">Wyloguj się</a></li>
                </ul>
            </nav>
        </header>

        <!-- Banner -->
        <section id="banner">
            <div class="inner">
                <header>
                    <h2>Witaj administratorze!</h2>
                </header>
            </div>
        </section>
        
        <!-- Main Content -->
        <article id="main">
            <section class="wrapper style2 container special-alt">
                <div class="row gtr-50">
                    <div class="col-12">
                        <header>
                            <h2>Wyszukiwanie użytkowników</h2>
                        </header>
                        <form method="post" action="">
                            <div class="row gtr-uniform">
                                <div class="col-6 col-12-xsmall">
                                    <input type="text" name="search_keyword" placeholder="Wyszukaj według loginu użytkownika"><br>
                                </div>
                                <div class="col-6 col-12-xsmall">
                                    <select name="role_filter">
                                        <option value="">Wszystkie role</option>
                                        <option value="1">Administrator</option>
                                        <option value="2">Moderator</option>
                                        <option value="3">Użytkownik</option>
                                    </select><br>
                                </div>
                                <div class="col-12">
                                    <input type="submit" value="Szukaj" name="search_users" class="primary">                      
                                </div>
                                <div class="col-12">
                                    <input type="submit" value="Pokaż wszystkich użytkowników" name="show_all_users" class="primary">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </article>
        
        <!-- Wyświetlanie znalezionych użytkowników -->
        <article id="main">
            <section class="wrapper style2 container special-alt">
                <div class="row gtr-50">
                    <div class="col-12">
                        <header>
                            <h2>Wyniki wyszukiwania</h2>
                        </header>
                        <div class="table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th style="text-align: left;">Login</th>
                                        <th style="text-align: left;">Rola</th>
                                        <th style="text-align: left;">Zalogowany</th>
                                        <th style="text-align: left;">Lekcje użytkownika</th> <!-- Dodana kolumna dla lekcji użytkownika -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    // Wyświetlanie wyników
                                    foreach ($users as $row) {
                                        echo "<tr>";
                                        echo "<td>{$row['login_uzyt_rola']}</td>";
                                        echo "<td>{$row['id_role_uzyt_rola']}</td>";
                                        echo "<td>";
                                        echo ($logged_in_username === $row['login_uzyt_rola']) ? "Tak" : "Nie";
                                        echo "</td>";
                                        echo "<td>";
                                        if (!empty($row['lekcje'])) {
                                            foreach ($row['lekcje'] as $lesson) {
                                                echo "{$lesson}<br>";
                                            }
                                        } else {
                                            echo "Brak lekcji";
                                        }
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </article>
    </div>
</body>
</html>

 <!-- Footer -->
 <footer id="footer">
            <ul class="icons">
                <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
            </ul>
            <ul class="copyright">
                <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </footer>
    </div>
    
    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>