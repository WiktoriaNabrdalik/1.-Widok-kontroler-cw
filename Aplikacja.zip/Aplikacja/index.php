<?php
include_once('db_connect.php');
session_start(); // Start sesji
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Aplikacja hiszpański</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="index is-preload">
<div id="page-wrapper">
    <!-- Header -->
    <header id="header" class="alt">
        <h1 id="logo">Aplikacja do nauki języka hiszpańskiego</h1>
        <nav id="nav">
            <ul>
                <li class="current"><a href="index.php">Strona główna</a></li>
                <li><a href="lessons.php" class="button primary">Lekcje</a></li>
                <?php
                if(isset($_SESSION['user_id'])) {
                    if ($_SESSION['role_id'] == '1') {
                        echo '<li><a href="admin_page.php" class="button primary">Moje konto</a></li>';
                    } else if ($_SESSION['role_id'] == '2') {
                        echo '<li><a href="moder_page.php" class="button primary">Moje konto</a></li>';
                    } else if ($_SESSION['role_id'] == '3') {
                        echo '<li><a href="user_page.php" class="button primary">Moje konto</a></li>';
                    }
                } else {
                    echo '<li><a href="login.php" class="button primary">Zaloguj się</a></li>';
                }
                ?>
            </ul>
        </nav>
    </header>

    <!-- Banner -->
    <section id="banner">
        <div class="inner">
            <header><h2>Witaj</h2></header>
            <p>w aplikacji do nauki języka hiszpańskiego <strong>przygotowanej dla Ciebie</strong><br /><br /><br />
                <h2>Wejdź do świata szybkiej nauki</h2>
            <footer>
                <ul class="buttons stacked">
                    <li><a href="#main" class="button fit scrolly">Wchodzę w to</a></li>
                </ul>
            </footer>
        </div>
    </section>

    <!-- Main -->
    <article id="main">
        <header class="special container">
            <span class="icon solid fa-heart"></span> 
            Szukasz <strong>sposobu</strong> na szybką naukę języka ?<br>
            Czy potrzebujesz pomocy w <strong>znalezieniu tajników efektywnej nauki</strong> języka obcego?<br><br>
            Jesteśmy tutaj, aby Ci pomóc!<br><br>
            W aplikacji znajdziesz lekcje, które w szybki i efektowny sposób pozwolą Ci poznać nowy język. 
        </header>

        <!-- Three -->
        <section class="wrapper style3 container special">
            <header class="major"> <h2>Lekcje dostosowane <strong>do twojego poziomu:</strong></h2></header>
            <div class="row">
                <div class="col-6 col-12-narrower">
                    <section>
                        <a href="A1.php" class="image featured"><img src="images/A1.jpg" alt="" /></a>
                        <header>
                            <h3>Poziom początkujący</h3>
                        </header>
                    </section>
                </div>
                <div class="col-6 col-12-narrower">
                    <section>
                        <a href="A2.php" class="image featured"><img src="images/A2.jpg" alt="" /></a>
                        <header>
                            <h3>Poziom podstawowy</h3>
                        </header>
                    </section>
                </div>
            </div>
            <div class="row">
                <div class="col-6 col-12-narrower">
                    <section>
                        <a href="B1.php" class="image featured"><img src="images/B1.jpg" alt="" /></a>
                        <header>
                            <h3>Poziom średnio zaawansowany</h3>
                        </header>
                    </section>
                </div>
                <div class="col-6 col-12-narrower">
                    <section>
                        <a href="B2.php" class="image featured"><img src="images/B2.jpg" alt="" /></a>
                        <header>
                            <h3>Poziom ponad średnio zaawansowany</h3>
                        </header>
                    </section>
                </div>
            </div>
        </section>

    <!-- CTA -->
    <section id="cta">
        <header><h2>Gotowy aby zacząć<strong> naukę nowego języka </strong>?</h2></header>
        <footer>
            <ul class="buttons">
                <li><a href="register.php" class="button primary">Rejestracja</a></li>
                <li><a href="login.php" class="button">Logowanie</a></li>
            </ul>
        </footer>
    </section>

    <!-- Footer -->
    <footer id="footer">
        <ul class="icons">
            <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
        </ul>
        <ul class="copyright">
            <li>&copy; Wiktoria Nabrdalik</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
        </ul>
    </footer>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>