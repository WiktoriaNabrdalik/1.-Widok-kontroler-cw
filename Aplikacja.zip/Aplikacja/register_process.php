<?php
session_start(); // Start sesji

// Połączenie z bazą danych
include_once('db_connect.php');

// Sprawdzenie, czy formularz został wysłany
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pobranie danych z formularza
    $first_name = $_POST["first_name"];
    $surname = $_POST["surname"];
    $birthday = $_POST["birthday"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $login = $_POST["login"];

    // Zabezpieczenie danych wejściowych przed SQL injection
    $first_name = mysqli_real_escape_string($conn, $first_name);
    $surname = mysqli_real_escape_string($conn, $surname);
    $birthday = mysqli_real_escape_string($conn, $birthday);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);
    $login = mysqli_real_escape_string($conn, $login);

    // Haszowanie hasła
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Sprawdzenie, czy nie ma już takiego loginu w bazie
    $check_login_query = "SELECT * FROM uzytkownik_rola WHERE login_uzyt_rola = '$login'";
    $check_login_result = mysqli_query($conn, $check_login_query);

    // Sprawdzenie, czy nie ma już takiego maila w bazie
    $check_email_query = "SELECT * FROM uzytkownicy WHERE email_uzyt = '$email'";
    $check_email_result = mysqli_query($conn, $check_email_query);

    if (mysqli_num_rows($check_login_result) > 0) {
        $_SESSION['message'] = "Podany login jest już zarejestrowany! Podaj inny.";
        header('Location: register.php');
        exit();
    } elseif (mysqli_num_rows($check_email_result) > 0) {
        $_SESSION['message'] = "Podany email jest już zarejestrowany! Podaj inny.";
        header('Location: register.php');
        exit();
    } else {
        $insert_user_query = "INSERT INTO uzytkownicy (imie_uzyt, nazwisko_uzyt, data_urodzenia_uzyt, email_uzyt) "
            . "VALUES ('$first_name', '$surname', '$birthday', '$email')";

        if (mysqli_query($conn, $insert_user_query)) {
            // Pobranie ID nowego użytkownika
            $user_id = mysqli_insert_id($conn);

            if ($user_id != 0) {
                // Dodanie nowego użytkownika do tabeli `uzytkownik_rola` z haszem hasła i rolą "Użytkownik"
                $insert_user_role_query = "INSERT INTO uzytkownik_rola (login_uzyt_rola, haslo_uzyt_rola, id_uzyt_uzyt_rola, id_role_uzyt_rola) "
                    . "VALUES ('$login', '$hashed_password', '$user_id', 3)"; // 3 to ID roli "Użytkownik"

                if (mysqli_query($conn, $insert_user_role_query)) {
                    // Ustawienie komunikatu w sesji
                    $_SESSION['message'] = 'Rejestracja zakończona pomyślnie! Możesz zalogować się na swoje konto.';
                    // Przekierowanie na stronę logowania
                    header('Location: login.php');
                    exit();
                } else {
                    $_SESSION['message'] = "Błąd podczas dodawania nowego użytkownika do tabeli `uzytkownik_rola`: " . mysqli_error($conn);
                    header('Location: register.php');
                    exit();
                }
            } else {
                $_SESSION['message'] = "Błąd podczas pobierania ID nowego użytkownika: " . mysqli_error($conn);
                header('Location: register.php');
                exit();
            }
        } else {
            $_SESSION['message'] = "Błąd podczas rejestracji użytkownika: " . mysqli_error($conn);
            header('Location: register.php');
            exit();
        }
    }
    mysqli_close($conn);
}
?>