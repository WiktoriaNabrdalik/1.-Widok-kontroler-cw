<?php
include_once('db_connect.php');
session_start(); // Start sesji

// Sprawdzenie czy użytkownik jest zalogowany i czy jest użytkownikiem
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != '3') {
    header("Location: login.php"); // Jeśli nie, przekierowanie na stronę logowania
    exit; 
}
$user_id = $_SESSION['user_id'];
$logged_in_username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Pobranie najnowszych danych użytkownika
$query = "SELECT login_uzyt_rola, email_uzyt FROM uzytkownik_rola JOIN uzytkownicy ON uzytkownik_rola.id_uzyt_uzyt_rola = uzytkownicy.id_uzyt WHERE id_uzyt = '$user_id'";
$result = mysqli_query($conn, $query);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $_SESSION['user_name'] = $row['login_uzyt_rola'];
    $_SESSION['user_email'] = $row['email_uzyt'];
} else {
    echo "Nie udało się pobrać danych użytkownika.";
}

// Obsługa usuwania lekcji
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_lesson'])) {
    $lesson_id = $_POST['lesson_id'];
    $delete_query = "DELETE FROM uzytkownik_lekcje WHERE id_lekcji = ? AND id_uzytkownik = ?";
    $stmt = mysqli_prepare($conn, $delete_query);
    mysqli_stmt_bind_param($stmt, "ii", $lesson_id, $user_id);
    if (mysqli_stmt_execute($stmt)) {
        echo "Lekcja została usunięta.";
    } else {
        echo "Błąd podczas usuwania lekcji: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Panel użytkownika</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/noscript.css" />
</head>
<body class="index is-preload">
    <div id="page-wrapper">
        <!-- Header -->
        <header id="header" class="alt">
            <h1 id="logo">Panel użytkownika</h1>
            <nav id="nav">
                <ul>
                    <li><a href="index.php" class="button">Strona główna</a></li>
                    <li><a href="lessons.php" class="button">Lekcje</a></li> <!-- Dodany przycisk Lekcje -->
                    <li><a href="logout.php" class="button">Wyloguj się</a></li>
                </ul>
            </nav>
        </header>
        
        <!-- Banner -->
        <section id="banner">
            <div class="inner">
                <header>
                    <h2>Witaj użytkowniku!</h2>
                </header>
            </div>
        </section>
        
        <!-- Main Content -->
        <article id="main">
            <section class="wrapper style2 container special-alt">
                <div class="row gtr-50">
                    <div class="col-12">
                        <header>
                            <h2>Twoje Lekcje</h2>
                        </header>
                        <p>Tutaj możesz wyświetlić listę swoich lekcji oraz zarządzać nimi.</p>
                        <div class="lesson-list">
                            <?php
                            // Zapytanie do bazy danych o lekcje użytkownika
                            $query = "SELECT * FROM lekcje JOIN uzytkownik_lekcje ON lekcje.id_lekcji = uzytkownik_lekcje.id_lekcji WHERE uzytkownik_lekcje.id_uzytkownik = '$user_id'";
                            $result = mysqli_query($conn, $query);

                            if ($result && mysqli_num_rows($result) > 0) {
                                // Wyświetlenie listy lekcji użytkownika
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<div class='lesson-item'>";
                                    echo "<h3>" . $row['nazwa_lekcji'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;POZIOM: " . $row['poziom_lekcji'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DATA UTWORZENIA: " . $row['data_utworzenia_lekcji'] . "</h3>";
                                    echo "<tr><td class='lesson-content' colspan='3'><pre>" . $row['tresc_lekcji'] . "</pre></td></tr>";
                                    echo "<tr><td colspan='3'>&nbsp;</td></tr>"; // Dodanie pustej komórki po każdej lekcji
                                    echo "<form method='post'><input type='hidden' name='lesson_id' value='" . $row['id_lekcji'] . "'><button type='submit' name='delete_lesson'>Usuń lekcje</button></form>"; // Formularz usuwania lekcji
                                    echo "</div>";
                                }
                            } else {
                                echo "<p>Nie masz jeszcze żadnych lekcji.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </section>
        </article>

        <!-- Footer -->
        <footer id="footer">
            <ul class="icons">
                <li><a href="https://github.com/WiktoriaNabrdalik/PSS" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
            </ul>
            <ul class="copyright">
                <li>&copy; Wiktoria Nabrdalik </li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
            </ul>
        </footer>
    </div>
    
    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dropotron.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollgress.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>

<?php
$conn->close();
?>